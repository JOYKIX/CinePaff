import asyncio
import logging

from divbot.discord_app import start_discord_bot
from divbot.twitch_app import start_twitch_bot


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    await asyncio.gather(start_discord_bot(), start_twitch_bot())


if __name__ == "__main__":
    asyncio.run(main())
