"""CinePaff's durable announcement queue. No Firebase Admin/common import here."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from urllib.parse import urlparse

import aiohttp
import discord

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASE_URL = "https://zogfilm-default-rtdb.europe-west1.firebasedatabase.app"
CHANNEL_ID = 1520922784698601644
log = logging.getLogger(__name__)


@dataclass(frozen=True)
class ScreeningConfig:
    database_url: str = DATABASE_URL
    channel_id: int = CHANNEL_ID
    poll_seconds: float = 10
    state_path: Path = BASE_DIR / "cinepaff.sqlite3"
    site_url: str = ""
    enabled: bool = True


def load_screening_config() -> ScreeningConfig:
    url = os.getenv("CINEPAFF_DATABASE_URL", DATABASE_URL).rstrip("/")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not (parsed.hostname or "").endswith((".firebasedatabase.app", ".firebaseio.com")) or parsed.query or parsed.username:
        raise ValueError("CINEPAFF_DATABASE_URL doit être une URL Firebase HTTPS.")
    poll = float(os.getenv("CINEPAFF_POLL_SECONDS", "10"))
    if not math.isfinite(poll) or not 5 <= poll <= 300:
        raise ValueError("CINEPAFF_POLL_SECONDS doit être compris entre 5 et 300.")
    channel = int(os.getenv("CINEPAFF_CHANNEL_ID", str(CHANNEL_ID)))
    if channel <= 0:
        raise ValueError("CINEPAFF_CHANNEL_ID invalide.")
    site = os.getenv("CINEPAFF_SITE_URL", "").strip()
    if site and (urlparse(site).scheme != "https" or not urlparse(site).netloc):
        raise ValueError("CINEPAFF_SITE_URL doit être une URL HTTPS.")
    state = Path(os.getenv("CINEPAFF_STATE_PATH", "cinepaff.sqlite3"))
    if not state.is_absolute():
        state = BASE_DIR / state
    return ScreeningConfig(url, channel, poll, state, site, os.getenv("CINEPAFF_ENABLED", "true").lower() not in {"false", "0", "no"})


def label(value: object, limit: int = 180) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Libellé manquant")
    text = re.sub(r"[\x00-\x1f\x7f]", " ", value).strip()[:limit]
    return discord.utils.escape_markdown(discord.utils.escape_mentions(text))


def timestamp(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError("Date invalide")
    if not 946684800000 <= value <= 253402300799000:
        raise ValueError("Date hors limites")
    return int(value / 1000)


def event_nonce(event_id: str) -> str:
    return hashlib.sha256(("cinepaff:" + event_id).encode()).hexdigest()[:24]


def build_screening_embed(event: dict, site_url: str = "") -> discord.Embed:
    if not isinstance(event, dict) or event.get("version") != 1:
        raise ValueError("Version inconnue")
    kind = event.get("type")
    headings = {"created": "🎬 Soirée programmée", "updated": "✏️ Soirée modifiée", "deleted": "✕ Soirée annulée"}
    verbs = {"created": "Programmée", "updated": "Modifiée", "deleted": "Annulée"}
    if kind not in headings or not isinstance(event.get("screening"), dict):
        raise ValueError("Événement invalide")
    label(event.get("screeningId"))
    current = event["screening"]
    movie = current.get("movie")
    if not isinstance(movie, dict):
        raise ValueError("Film manquant")
    title = label(movie.get("title"), 120)
    actor = label(event.get("actor"), 70)
    start = timestamp(current.get("startsAt"))
    at = timestamp(event.get("at"))
    embed = discord.Embed(
        title=title,
        description=f"{verbs[kind]} par **{actor}**",
        color={"created": 0xDFFF5F, "updated": 0xA78BFA, "deleted": 0xEF7373}[kind],
        timestamp=datetime.fromtimestamp(at, timezone.utc),
    )
    embed.set_author(name=headings[kind])
    when = f"<t:{start}:F>"
    if kind != "deleted":
        when += f" · <t:{start}:R>"
    embed.add_field(name="Prévue le" if kind == "deleted" else "Quand", value=when, inline=False)
    previous = event.get("previous")
    if kind == "updated":
        if not isinstance(previous, dict) or not isinstance(previous.get("movie"), dict):
            raise ValueError("État précédent manquant")
        old_start = timestamp(previous.get("startsAt"))
        changes = []
        if old_start != start:
            changes.append(f"<t:{old_start}:F>")
        if previous["movie"].get("title") != movie.get("title"):
            changes.append(label(previous["movie"].get("title"), 120))
        if changes:
            embed.add_field(name="Auparavant", value=" · ".join(changes), inline=False)
    if current.get("createdBy") and current["createdBy"] != event.get("actor"):
        embed.add_field(name="Organisée par", value=label(current["createdBy"], 70), inline=False)
    poster = movie.get("posterPath", "")
    if isinstance(poster, str) and re.fullmatch(r"/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp)", poster):
        embed.set_thumbnail(url="https://image.tmdb.org/t/p/w342" + poster)
    if site_url and kind != "deleted":
        embed.url = site_url.split("#")[0] + "#screenings"
    embed.set_footer(text="CinePaff · Soirées")
    return embed


class EventStore:
    """One durable delivery record per immutable Firebase event id."""
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY, payload TEXT NOT NULL, state TEXT NOT NULL, started_at REAL, message_id TEXT)")
        self.db.commit()

    def ingest(self, events: dict) -> None:
        with self.db:
            for key, event in sorted(events.items()):
                if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", key):
                    continue
                if self.db.execute("SELECT 1 FROM announcements WHERE id=?", (key,)).fetchone():
                    continue
                try:
                    payload = json.dumps(event, ensure_ascii=False, allow_nan=False)
                    if len(payload) > 16000:
                        raise ValueError("Événement trop grand")
                    build_screening_embed(event)
                    state = "pending"
                except (ValueError, TypeError, OverflowError):
                    payload, state = "{}", "invalid"
                    log.warning("[CINEPAFF] Événement invalide ignoré : %s", key)
                self.db.execute("INSERT INTO announcements(id,payload,state) VALUES(?,?,?)", (key, payload, state))

    def pending(self) -> list:
        rows = self.db.execute("SELECT id,payload,started_at FROM announcements WHERE state='pending' ORDER BY id").fetchall()
        return [(key, json.loads(payload), started) for key, payload, started in rows]

    def begin(self, key: str) -> None:
        with self.db:
            self.db.execute("UPDATE announcements SET started_at=COALESCE(started_at,?) WHERE id=?", (time.time(), key))

    def delivered(self, key: str, message_id: int) -> None:
        with self.db:
            self.db.execute("UPDATE announcements SET state='sent',message_id=? WHERE id=?", (str(message_id), key))

    def close(self) -> None:
        self.db.close()


class WorkerLock:
    """OS lock releases on crashes; prevents two local instances sending together."""
    def __init__(self, path: Path):
        self.path = path
        self.file = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a+b")
        self.file.write(b"0")
        self.file.flush()
        self.file.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise RuntimeError("Un relais CinePaff utilise déjà ce fichier d'état.") from None
        return self

    def __exit__(self, *_):
        if self.file is not None:
            if os.name == "nt":
                import msvcrt
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            self.file.close()


class FirebaseEventSource:
    def __init__(self, session: aiohttp.ClientSession, database_url: str):
        self.session = session
        self.url = database_url + "/screeningEvents.json"
        self.etag = None

    async def read(self) -> dict | None:
        headers = {"X-Firebase-ETag": "true"}
        if self.etag:
            headers["If-None-Match"] = self.etag
        async with self.session.get(self.url, headers=headers) as response:
            if response.status == 304:
                return None
            if response.status != 200:
                raise RuntimeError(f"Lecture Firebase refusée (HTTP {response.status})")
            events = await response.json()
            if events is not None and not isinstance(events, dict):
                raise ValueError("File Firebase invalide")
            self.etag = response.headers.get("ETag")
            return events or {}


class ScreeningNotifier:
    def __init__(self, bot: discord.Client, config: ScreeningConfig):
        self.bot = bot
        self.config = config
        self.task: asyncio.Task | None = None

    def start(self) -> None:
        if self.config.enabled and (self.task is None or self.task.done()):
            self.task = asyncio.create_task(self.run(), name="cinepaff-announcements")

    async def close(self) -> None:
        if self.task is not None:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None

    async def channel(self):
        channel = self.bot.get_channel(self.config.channel_id)
        if channel is None:
            channel = await self.bot.fetch_channel(self.config.channel_id)
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            raise RuntimeError("Le salon CinePaff doit être un salon texte.")
        me = channel.guild.me
        if me is None:
            raise RuntimeError("Le bot n'est pas prêt dans le serveur CinePaff.")
        permissions = channel.permissions_for(me)
        can_send = permissions.send_messages_in_threads if isinstance(channel, discord.Thread) else permissions.send_messages
        if not (permissions.view_channel and can_send and permissions.embed_links and permissions.read_message_history):
            raise RuntimeError("Permissions CinePaff requises : voir, envoyer, intégrer des liens, lire l'historique.")
        return channel

    async def deliver_pending(self, store: EventStore) -> int:
        pending = store.pending()
        if not pending:
            return 0
        channel = await self.channel()
        count = 0
        for key, event, started in pending:
            nonce = event_nonce(key)
            # After an ambiguous failure/crash, reconcile with Discord before resending.
            if started is not None:
                after = datetime.fromtimestamp(started - 60, timezone.utc)
                existing = None
                async for message in channel.history(after=after, limit=None, oldest_first=True):
                    if message.author.id == self.bot.user.id and str(message.nonce) == nonce:
                        existing = message
                        break
                if existing is not None:
                    store.delivered(key, existing.id)
                    count += 1
                    continue
            store.begin(key)
            message = await channel.send(
                embed=build_screening_embed(event, self.config.site_url),
                allowed_mentions=discord.AllowedMentions.none(),
                nonce=nonce,
            )
            store.delivered(key, message.id)
            count += 1
            log.info("[CINEPAFF] Annonce %s envoyée (%s).", event["type"], key)
        return count

    async def run(self) -> None:
        store = None
        try:
            await self.bot.wait_until_ready()
            with WorkerLock(self.config.state_path.with_suffix(".lock")):
                store = EventStore(self.config.state_path)
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as session:
                    source = FirebaseEventSource(session, self.config.database_url)
                    failures = 0
                    log.info("[CINEPAFF] Relais actif, salon %s, intervalle %ss.", self.config.channel_id, self.config.poll_seconds)
                    while not self.bot.is_closed():
                        await self.bot.wait_until_ready()
                        failed = False
                        try:
                            events = await source.read()
                            if events is not None:
                                store.ingest(events)
                        except asyncio.CancelledError:
                            raise
                        except Exception as error:
                            source.etag = None
                            failed = True
                            log.warning("[CINEPAFF] Lecture en attente (%s).", type(error).__name__)
                        try:
                            await self.deliver_pending(store)
                        except asyncio.CancelledError:
                            raise
                        except Exception as error:
                            failed = True
                            log.warning("[CINEPAFF] Envoi en attente (%s, statut %s). Vérifier la connexion et les permissions du salon.", type(error).__name__, getattr(error, "status", "n/a"))
                        failures = min(failures + 1, 4) if failed else 0
                        await asyncio.sleep(min(60, self.config.poll_seconds * 2 ** failures))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            log.error("[CINEPAFF] Relais arrêté (%s). Vérifier le fichier d'état et l'absence d'une seconde instance.", type(error).__name__)
        finally:
            if store is not None:
                store.close()
