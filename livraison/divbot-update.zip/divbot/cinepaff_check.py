"""Read-only checks: no bot startup, Firebase writes or Discord messages."""
import asyncio
import os

import aiohttp
import discord
from dotenv import load_dotenv

from divbot.cinepaff import BASE_DIR, FirebaseEventSource, load_screening_config


async def check() -> int:
    load_dotenv(BASE_DIR / ".env")
    config = load_screening_config()
    problems = 0
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as session:
        try:
            events = await FirebaseEventSource(session, config.database_url).read()
            print(f"OK Firebase CinePaff : file accessible ({len(events or {})} événements).")
        except Exception as error:
            print(f"ERREUR Firebase CinePaff : {type(error).__name__}. Vérifier CINEPAFF_DATABASE_URL et les règles de lecture de screeningEvents.")
            problems += 1
        token = os.getenv("DISCORD_TOKEN", "").strip()
        if not token:
            print("ERREUR : DISCORD_TOKEN manquant.")
            return 1

        async def get(path):
            async with session.get("https://discord.com/api/v10" + path, headers={"Authorization": "Bot " + token}) as response:
                if response.status != 200:
                    raise RuntimeError(f"Discord HTTP {response.status}")
                return await response.json()

        try:
            user = await get("/users/@me")
            channel = await get(f"/channels/{config.channel_id}")
            if channel.get("type") not in (0, 5):
                raise RuntimeError("Le diagnostic attend un salon texte ou d'annonces.")
            guild_id = channel["guild_id"]
            member = await get(f"/guilds/{guild_id}/members/{user['id']}")
            roles = await get(f"/guilds/{guild_id}/roles")
            member_roles = set(member["roles"]) | {guild_id}
            bits = 0
            for role in roles:
                if role["id"] in member_roles:
                    bits |= int(role["permissions"])
            permissions = discord.Permissions(bits)
            if not permissions.administrator:
                overwrites = channel.get("permission_overwrites", [])
                def apply(deny, allow):
                    nonlocal bits
                    bits = (bits & ~deny) | allow
                for overwrite in overwrites:
                    if overwrite["id"] == guild_id:
                        apply(int(overwrite["deny"]), int(overwrite["allow"]))
                allow = deny = 0
                for overwrite in overwrites:
                    if overwrite["type"] == 0 and overwrite["id"] != guild_id and overwrite["id"] in member_roles:
                        allow |= int(overwrite["allow"])
                        deny |= int(overwrite["deny"])
                apply(deny, allow)
                for overwrite in overwrites:
                    if overwrite["type"] == 1 and overwrite["id"] == user["id"]:
                        apply(int(overwrite["deny"]), int(overwrite["allow"]))
                permissions = discord.Permissions(bits)
                missing = [name for name in ("view_channel", "send_messages", "embed_links", "read_message_history") if not getattr(permissions, name)]
            else:
                missing = []
            if missing:
                print("ERREUR permissions du salon : " + ", ".join(missing))
                problems += 1
            else:
                print(f"OK Discord : accès et permissions du salon {config.channel_id}.")
        except RuntimeError as error:
            # All RuntimeError messages above are fixed strings without credentials.
            print("ERREUR : " + str(error))
            problems += 1
        except Exception as error:
            print(f"ERREUR connexion Discord : {type(error).__name__}.")
            problems += 1
    print("Diagnostic terminé. Aucun message envoyé, aucune donnée modifiée.")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(check()))
