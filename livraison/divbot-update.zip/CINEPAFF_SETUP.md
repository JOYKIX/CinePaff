# CinePaff → Discord

Les créations, modifications et annulations dans **Soirées** publient un nouveau message dans le salon **1520922784698601644**. Chaque message indique le film, la date/heure et l'auteur de l'action ; les modifications affichent aussi l'ancien horaire ou l'ancien film. Les dates Discord suivent le fuseau de chaque lecteur. Aucun rôle ni membre n'est mentionné.

## Installer sur ton hébergeur

1. Arrêter l'ancienne instance du bot.
2. Extraire le contenu de **divbot-update.zip** à la racine du bot, en remplaçant les fichiers correspondants. Conserver le fichier .env, le dossier firebase et les bases SQLite existantes : l'archive n'inclut aucun de ces secrets ou fichiers de données.
3. Avec Python 3.10 ou plus récent, exécuter :

~~~sh
python -m pip install -r requirements.txt
python -m divbot.cinepaff_check
python bot.py
~~~

Utiliser ensuite la commande de redémarrage habituelle de l'hébergeur, au lieu de lancer une deuxième instance. Le diagnostic vérifie uniquement les accès Firebase et Discord : il ne publie rien et ne modifie aucune donnée.

4. Publier aussi le nouveau site. Le dossier client de **cinepaff-site.zip** contient les fichiers publics à déployer ; le dossier server contient le Worker existant. Conserver la méthode de publication habituelle du site.

Les réglages CinePaff sont déjà les valeurs par défaut : aucun nouveau secret ni webhook Discord à créer. Le jeton DISCORD_TOKEN existant reste dans le bot. Le salon doit autoriser **Voir le salon**, **Envoyer des messages**, **Intégrer des liens** et **Voir les anciens messages**. Les contrôles locaux en lecture seule ont confirmé ces accès avec le jeton actuel.

Le démarrage normal du bot synchronise les commandes Discord et démarre le relais automatiquement. Une ligne [CINEPAFF] Relais actif confirme son démarrage. Le relais vérifie la file toutes les 10 secondes ; en cas d'erreur, il réessaie avec un délai pouvant atteindre 60 secondes.

## Données et reprise

Le site enregistre chaque action dans **screeningEvents**, en une seule écriture atomique avec la modification de **screenings**. Une sauvegarde échouée ne crée donc pas d'annonce ; une sauvegarde sans changement de film/horaire n'en crée pas non plus. L'annulation conserve dans l'événement une copie du titre, de l'horaire et de l'organisateur.

Le bot lit la base **zogfilm**, séparément de sa base **zogbot**. Ne pas remplacer FIREBASE_DATABASE_URL par l'URL du site. Le lecteur utilise l'accès REST autorisé par les règles actuelles du site ; aucun changement des règles Firebase n'a été effectué. Le site déployé doit pouvoir écrire screeningEvents comme screenings. Si les règles sont restreintes à l'avenir, prévoir aussi un accès serveur dédié à cette file.

Le bot conserve les événements reçus et les identifiants de messages dans **cinepaff.sqlite3**. Ce fichier doit être placé sur un volume persistant et conservé à chaque redéploiement. CINEPAFF_STATE_PATH permet d'en choisir le chemin. Lancer une seule instance du relais ; le verrou local empêche deux instances utilisant le même fichier de travailler ensemble. Des instances sur des machines ou volumes distincts doivent être évitées.

Les actions accumulées pendant un arrêt seront envoyées dans l'ordre des identifiants Firebase à la reprise. Les deux soirées préexistantes à cette mise à jour ne sont pas annoncées rétroactivement : seules les actions enregistrées par le nouveau site alimentent la file. Les événements envoyés ne sont pas supprimés automatiquement de Firebase ; garder cette file permet la reprise. Ne pas effacer le fichier SQLite, sinon les événements de la file seront considérés comme nouveaux.

Chaque événement conserve le même nonce Discord lors d'une nouvelle tentative. Le bot vérifie aussi l'historique après un envoi dont la réponse a été perdue. Discord ne garantit l'unicité du nonce que sur les dernières minutes ; conserver la base locale reste nécessaire. Voir la [documentation Discord Create Message](https://docs.discord.com/developers/resources/message#create-message).

## Division War retiré

Le moteur, l'XP automatique des messages, les statistiques de combat, la commande /team membres et les champs Puissance ont été retirés du code actif. Les équipes, points, classements, capitaines, règles Twitch et liaisons de comptes restent disponibles. La résolution des équipes Twitch utilise les rôles Discord.

L'ancien fichier division_war.py peut être retiré du serveur : il n'est plus importé. La base division_war.sqlite3 reste intacte mais n'est plus utilisée. Sur le poste de développement, le moteur a été archivé dans .local et les sources originales sauvegardées dans .local/before-cinepaff. Ces sauvegardes ne sont pas incluses dans l'archive de mise à jour.

## Vérifier sans messages réels

~~~sh
python -m unittest discover -s tests -v
~~~

Les tests simulent Firebase et Discord : créations, modifications, annulations, erreurs, reprise après redémarrage, réponse Discord perdue, doublons, horodatage, absence de mentions, chargement du bot et fonctionnement des équipes sans Division War. Côté site, tools/verify-discord.mjs vérifie le parcours navigateur et l'écriture atomique ; tools/verify-screenings.mjs vérifie les permissions et les autres fonctions des soirées.
