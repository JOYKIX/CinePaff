"""Import the real bot in a subprocess with credentials, Firebase and HTTP mocked."""
import os
from pathlib import Path
import subprocess
import sys
import unittest


class BotIntegrationTests(unittest.TestCase):
    def test_bot_commands_teams_and_twitch_without_division_war(self):
        script = r'''
import asyncio
import os
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

async def verify():
    fake_env={"TWITCH_TOKEN":"oauth:fixture","TWITCH_CHANNEL":"fixture","DISCORD_TOKEN":"fixture","GUILD_ID":"123","CINEPAFF_ENABLED":"false"}
    with patch.dict(os.environ,fake_env), patch("dotenv.load_dotenv"), patch("firebase_admin.credentials.Certificate"), patch("firebase_admin.initialize_app",side_effect=RuntimeError("offline fixture")), patch("aiohttp.ClientSession._request",side_effect=AssertionError("No HTTP allowed in tests")):
        from divbot import common, discord_app, twitch_app, team_logic
        bot=discord_app.discord_bot
        assert not hasattr(bot,"division_war")
        assert not hasattr(bot,"initialize_team_member_profiles")
        assert "membres" not in {cmd.name for cmd in discord_app.team_group.commands}
        assert {"captain","vicecaptain","leaderboard","detail","list"} <= {cmd.name for cmd in discord_app.team_group.commands}
        async with bot:
            await bot.setup_hook()
            assert bot.screening_notifier.task is None
            bot.process_commands=AsyncMock()
            await bot.on_message(SimpleNamespace(author=SimpleNamespace(bot=False)))
            bot.process_commands.assert_awaited_once()
            member=SimpleNamespace(id=99,display_name="Alex",mention="<@99>")
            role=SimpleNamespace(id=7,name="blue",members=[member],mention="<@&7>")
            member.roles=[role]
            guild=SimpleNamespace(get_role=lambda key:role if key==7 else None,get_member=lambda key:member if key==99 else None)
            common.teams["teams"]={"blue":{"role_id":7,"points":10,"emoji":"B","total_wins":2}}
            embed=team_logic.leaderboard_embed(guild)
            assert "Puissance" not in str(embed.to_dict())
            assert "Points: 10" in str(embed.to_dict())
            detail=team_logic.team_detail_embed(guild,role)
            assert "Puissance" not in str(detail.to_dict())
            assert any(field.name=="Membres" for field in detail.fields)
            common.links["alex"]=99
            bot.get_cached_guild=lambda key:guild
            resolved=await twitch_app.TwitchBot.resolve_team_name_for_twitch_user(None,"alex")
            assert resolved=="blue"
            assert await twitch_app.TwitchBot.resolve_team_name_for_twitch_user(None,"missing") is None
        assert bot.is_closed()
    print("PASS: real bot imports, commands, message handling, team standings, Twitch role resolution and clean shutdown; no external calls.")

asyncio.run(verify())
'''
        result=subprocess.run([sys.executable,"-c",script],cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,encoding="utf-8",env={**os.environ,"PYTHONIOENCODING":"utf-8"},timeout=40)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
