import asyncio
import copy
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from divbot.cinepaff import (
    CHANNEL_ID, EventStore, FirebaseEventSource, ScreeningConfig, ScreeningNotifier,
    WorkerLock, build_screening_embed, event_nonce, load_screening_config,
)


def event(kind="created", **changes):
    value = {
        "version": 1, "type": kind, "screeningId": "screening-1", "at": 1789000000000,
        "actor": "Alex", "screening": {"movie": {"title": "Initial D Legend", "posterPath": "/poster.jpg"}, "startsAt": 1789300000000, "createdBy": "Alex"},
    }
    if kind == "updated":
        value["previous"] = copy.deepcopy(value["screening"])
        value["previous"]["startsAt"] -= 3600000
    value.update(changes)
    return value


class FakeChannel:
    def __init__(self):
        self.messages = []
        self.calls = []
        self.failure = None
        self.history_calls = 0

    async def send(self, **kwargs):
        self.calls.append(kwargs)
        if self.failure == "before":
            self.failure = None
            raise OSError("offline")
        msg = SimpleNamespace(id=len(self.messages)+1, nonce=kwargs["nonce"], author=SimpleNamespace(id=17))
        self.messages.append(msg)
        if self.failure == "after":
            self.failure = None
            raise OSError("response lost")
        return msg

    async def history(self, **kwargs):
        self.history_calls += 1
        for message in self.messages:
            yield message


class NotificationTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name)/"state.sqlite3"
        self.store = EventStore(self.path)
        self.channel = FakeChannel()
        self.bot = SimpleNamespace(user=SimpleNamespace(id=17))
        self.notifier = ScreeningNotifier(self.bot, ScreeningConfig(state_path=self.path))
        self.notifier.channel = AsyncMock(return_value=self.channel)

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    async def test_each_action_once_and_restarts(self):
        values = {"a": event(), "b": event("updated"), "c": event("deleted")}
        self.store.ingest(values)
        self.assertEqual(await self.notifier.deliver_pending(self.store), 3)
        self.store.close()
        self.store = EventStore(self.path)
        self.store.ingest(values)
        self.assertEqual(await self.notifier.deliver_pending(self.store), 0)
        self.assertEqual(len(self.channel.messages), 3)
        self.assertEqual([call["embed"].author.name for call in self.channel.calls], ["🎬 Soirée programmée", "✏️ Soirée modifiée", "✕ Soirée annulée"])
        for call in self.channel.calls:
            self.assertEqual(call["allowed_mentions"].to_dict()["parse"], [])
            self.assertLessEqual(len(call["nonce"]), 25)

    async def test_failed_send_retries_after_restart_in_order(self):
        self.store.ingest({"a": event(), "b": event("deleted")})
        self.channel.failure = "before"
        with self.assertRaises(OSError):
            await self.notifier.deliver_pending(self.store)
        self.assertEqual(len(self.store.pending()), 2)
        self.store.close()
        self.store = EventStore(self.path)
        await self.notifier.deliver_pending(self.store)
        self.assertEqual(len(self.channel.messages), 2)
        self.assertEqual(self.store.pending(), [])

    async def test_lost_response_reconciles_without_duplicate(self):
        self.store.ingest({"a": event()})
        self.channel.failure = "after"
        with self.assertRaises(OSError):
            await self.notifier.deliver_pending(self.store)
        self.store.close()
        self.store = EventStore(self.path)
        await self.notifier.deliver_pending(self.store)
        self.assertEqual(len(self.channel.calls), 1)
        self.assertEqual(len(self.channel.messages), 1)
        self.assertEqual(self.store.pending(), [])

    async def test_pending_survives_firebase_deletion(self):
        self.store.ingest({"a": event("deleted")})
        self.store.ingest({})
        await self.notifier.deliver_pending(self.store)
        self.assertEqual(len(self.channel.messages), 1)

    async def test_invalid_event_does_not_block_queue(self):
        self.store.ingest({"a": {"version": 99}, "b": event(), "c": {**event(), "at": float("nan")}})
        await self.notifier.deliver_pending(self.store)
        self.assertEqual(len(self.channel.messages), 1)
        self.assertEqual(self.channel.calls[0]["nonce"], event_nonce("b"))

    async def test_an_existing_id_cannot_change_a_queued_event(self):
        self.store.ingest({"a": event()})
        self.store.ingest({"a": event("deleted")})
        await self.notifier.deliver_pending(self.store)
        self.assertEqual(self.channel.calls[0]["embed"].author.name, "🎬 Soirée programmée")

    async def test_no_old_screenings_backfill(self):
        self.store.ingest({})
        await self.notifier.deliver_pending(self.store)
        self.notifier.channel.assert_not_awaited()

    async def test_lifecycle_start_once_and_cancel(self):
        entered = asyncio.Event()
        async def worker():
            entered.set()
            await asyncio.Future()
        self.notifier.run = worker
        self.notifier.start()
        original = self.notifier.task
        self.notifier.start()
        self.assertIs(self.notifier.task, original)
        await entered.wait()
        await self.notifier.close()
        self.assertTrue(original.cancelled())
        self.assertIsNone(self.notifier.task)

    def test_lock_prevents_second_local_worker_and_releases(self):
        path = self.path.with_suffix(".lock")
        with WorkerLock(path):
            with self.assertRaises(RuntimeError):
                with WorkerLock(path):
                    pass
        with WorkerLock(path):
            pass


class FormattingTests(unittest.TestCase):
    def test_update_has_both_dates_and_cancellation_keeps_film(self):
        edit = build_screening_embed(event("updated"))
        self.assertEqual([field.name for field in edit.fields], ["Quand", "Auparavant"])
        self.assertIn("<t:", edit.fields[0].value)
        deleted = build_screening_embed(event("deleted"))
        self.assertEqual(deleted.title, "Initial D Legend")
        self.assertEqual(deleted.fields[0].name, "Prévue le")
        self.assertNotIn(":R>", deleted.fields[0].value)

    def test_different_actor_and_movie_change(self):
        value=event("updated", actor="Admin")
        value["previous"]["movie"]["title"]="Drive"
        embed=build_screening_embed(value)
        self.assertIn("Drive", embed.fields[1].value)
        self.assertEqual(embed.fields[2].value,"Alex")

    def test_untrusted_text_and_images(self):
        value=event(actor="@everyone **Alex**")
        value["screening"]["movie"]["posterPath"]="https://untrusted.invalid/image.jpg"
        embed=build_screening_embed(value)
        self.assertNotIn("@everyone",embed.description)
        self.assertIn(r"\*\*Alex\*\*",embed.description)
        self.assertIsNone(embed.thumbnail.url)

    def test_link_and_limits(self):
        value=event(actor="x"*300)
        value["screening"]["movie"]["title"]="*"*1000
        embed=build_screening_embed(value,"https://example.com/#home")
        self.assertLessEqual(len(embed.title),256)
        self.assertEqual(embed.url,"https://example.com/#screenings")
        self.assertLess(len(embed),6000)

    def test_config_uses_site_database_not_bots_database(self):
        with patch.dict("os.environ",{"FIREBASE_DATABASE_URL":"https://zogbot-default-rtdb.europe-west1.firebasedatabase.app/"},clear=True):
            config=load_screening_config()
        self.assertIn("zogfilm",config.database_url)
        self.assertEqual(config.channel_id,CHANNEL_ID)
        self.assertEqual(config.poll_seconds,10)

    def test_invalid_dates_rejected(self):
        for date in [None,True,-1,"tomorrow",float("inf"),1e25]:
            value=event();value["screening"]["startsAt"]=date
            with self.assertRaises(ValueError): build_screening_embed(value)


class SourceTests(unittest.IsolatedAsyncioTestCase):
    def response(self,status,data=None,headers=None):
        response=AsyncMock()
        response.status=status;response.headers=headers or {}
        response.json.return_value=data
        response.__aenter__.return_value=response
        return response

    async def test_etag_and_no_queue_treated_as_empty(self):
        response=self.response(200,None,{"ETag":"v1"})
        session=SimpleNamespace(get=lambda *args,**kwargs:response)
        source=FirebaseEventSource(session,"https://example.firebaseio.com")
        self.assertEqual(await source.read(),{})
        self.assertEqual(source.etag,"v1")
        response.status=304
        self.assertIsNone(await source.read())

    async def test_failed_read_is_not_an_empty_snapshot(self):
        response=self.response(403)
        source=FirebaseEventSource(SimpleNamespace(get=lambda *args,**kwargs:response),"https://example.firebaseio.com")
        with self.assertRaises(RuntimeError): await source.read()
        self.assertIsNone(source.etag)
